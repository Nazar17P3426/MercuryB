MercuryB by Tuanminh

This is skidded 6 payload malware
My new skidded malware