/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef HE0450-2958_PRIVATE_H
#define HE0450-2958_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.1.0.0"
#define VER_MAJOR	1
#define VER_MINOR	1
#define VER_RELEASE	0
#define VER_BUILD	0
#define COMPANY_NAME	"Tuanminh"
#define FILE_VERSION	"1.1.0.0"
#define FILE_DESCRIPTION	"MercuryB 1.1"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	""
#define PRODUCT_VERSION	"1.1.0.0"

#endif /*HE0450-2958_PRIVATE_H*/
